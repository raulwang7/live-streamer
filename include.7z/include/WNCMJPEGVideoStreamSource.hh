#include "JPEGVideoSource.hh"

class WNCMJPEGVideoStreamSource: public JPEGVideoSource 
{
	public:
		static WNCMJPEGVideoStreamSource* createNew(UsageEnvironment& env, FramedSource* source);

		virtual u_int8_t type() { return fType; }
		virtual u_int8_t qFactor() { return fQuality; }
		virtual u_int8_t width() { return fWidth; }
		virtual u_int8_t height() { return fHeight; }
		
	private:
		WNCMJPEGVideoStreamSource(UsageEnvironment& env, FramedSource* source);
		~WNCMJPEGVideoStreamSource();

		virtual void doGetNextFrame();
		static void afterGettingFrame(void* clientData, unsigned frameSize,unsigned numTruncatedBytes,struct timeval presentationTime,unsigned durationInMicroseconds);
		void afterGettingFrame1(unsigned frameSize, unsigned numTruncatedBytes, struct timeval presentationTime, unsigned durationInMicroseconds);
              u_int8_t const* quantizationTables(u_int8_t& precision, u_int16_t& length);
              
	private:
		FramedSource* fInputSource;
		u_int8_t fType;
              u_int8_t fWidth;
              u_int8_t fHeight;
              u_int8_t fQuality;
              u_int8_t fPrecision;
  		u_int8_t fReserved;
              u_int8_t fQuantizationTables[128];
              u_int16_t fQtableLength;
};

