#ifndef _H264_VIDEO_STREAM_DISCRETE_FRAMER_HH
#define _H264_VIDEO_STREAM_DISCRETE_FRAMER_HH

#ifndef _WIS_INPUT_HH
#include "WISInput.hh"
#endif

#ifndef _H264_OR_5_VIDEO_STREAM_DISCRETE_FRAMER_HH
#include "H264or5VideoStreamDiscreteFramer.hh"
#endif

struct NALU
{
	u_int32_t timeStamp;
	u_int16_t don;
	u_int32_t size;
	u_int8_t * addr;
	u_int8_t nalu_type;
};

#define MAX_NALU_NUM_PER_FRAME	8

class WNCH264VideoStreamDiscreteFramer: public H264or5VideoStreamDiscreteFramer {
public:
  static WNCH264VideoStreamDiscreteFramer*
  createNew(UsageEnvironment& env, FramedSource* inputSource);

protected:
  WNCH264VideoStreamDiscreteFramer(UsageEnvironment& env, FramedSource* inputSource);
      // called only by createNew()
  virtual ~WNCH264VideoStreamDiscreteFramer();

private:
  // redefined virtual functions:
  virtual void doGetNextFrame();
  
  static void afterGettingFrame(void* clientData, unsigned frameSize,
                                unsigned numTruncatedBytes,
                                struct timeval presentationTime,
                                unsigned durationInMicroseconds);
  void afterGettingFrame1(unsigned frameSize,
                          unsigned numTruncatedBytes,
                          struct timeval presentationTime,
                          unsigned durationInMicroseconds);

  virtual Boolean nalUnitEndsAccessUnit(u_int8_t nal_unit_type);
  
  // redefined virtual functions:
  virtual Boolean isH264VideoStreamFramer() const;

  private:
    unsigned char fBuffer[MEDIA_MAX_FRAME_SIZE];
    NALU fNalus[MAX_NALU_NUM_PER_FRAME];
    u_int32_t fNaluCurrIndex;
    u_int32_t fNaluCount;
};

#define AUDHEAD 0x00000109
#define SEIHEAD 0x00000106
#define SPSHEAD 0x00000107
#define PPSHEAD 0x00000108
#define IDRHEAD 0x00000105
#define NALUHEAD 0x00000101


#define NALU_TYPE_NONIDR		1
#define NALU_TYPE_IDR		5
#define NALU_TYPE_SEI		6
#define NALU_TYPE_SPS		7
#define NALU_TYPE_PPS		8
#define NALU_TYPE_AUD		9
#endif

