#include "assert.h"
#include "WNCMJPEGVideoStreamSource.hh"

WNCMJPEGVideoStreamSource* 
WNCMJPEGVideoStreamSource::createNew(UsageEnvironment& env, FramedSource* source)
{
	return new WNCMJPEGVideoStreamSource(env, source);
}

WNCMJPEGVideoStreamSource::WNCMJPEGVideoStreamSource(UsageEnvironment& env, FramedSource* source)
	:JPEGVideoSource(env), fInputSource(source), fType(0), fWidth(0), fHeight(0), fQuality(255), fPrecision(0), fQtableLength(0) {

}

WNCMJPEGVideoStreamSource::~WNCMJPEGVideoStreamSource() {
	 Medium::close(fInputSource);
}

u_int8_t const* WNCMJPEGVideoStreamSource::quantizationTables(u_int8_t& precision, u_int16_t& length)
{
	precision = fPrecision;
	length = fQtableLength;
	return fQuantizationTables;       
}

void WNCMJPEGVideoStreamSource::doGetNextFrame()
{
	if (fInputSource)
	{
		fInputSource->getNextFrame(fTo, fMaxSize, 
								   afterGettingFrame, this, 
								   FramedSource::handleClosure, this);
	}
}

void WNCMJPEGVideoStreamSource::afterGettingFrame(void* clientData, unsigned frameSize, unsigned numTruncatedBytes,
													 struct timeval presentationTime,unsigned durationInMicroseconds)
{
	WNCMJPEGVideoStreamSource* source = (WNCMJPEGVideoStreamSource*) clientData;
	source->afterGettingFrame1(frameSize, numTruncatedBytes, presentationTime, durationInMicroseconds);
}

void WNCMJPEGVideoStreamSource::afterGettingFrame1(unsigned frameSize, unsigned numTruncatedBytes,
												  struct timeval presentationTime,unsigned durationInMicroseconds)
{	
	unsigned char* pFrame = fTo;
	unsigned char* pFrame_end = fTo + frameSize - 1;

	fFrameSize = frameSize;
	fQuality = 60;
	
	do 
	{	
		if (*(pFrame_end - 1) != 0xFF || *(pFrame_end) != 0xD9) 
		{// EOI
			envir() << "WNCMJPEGVideoStreamSource::afterGettingFrame1: EOI\n";
			break;
		}
		
		pFrame_end -= 1;
		
		if ((*pFrame++ != 0xFF) || (*pFrame++ != 0xD8)) 
		{// SOI
			envir() << "WNCMJPEGVideoStreamSource::afterGettingFrame1: SOI\n";
			break;
		}
		
		if ((pFrame > pFrame_end) || (*pFrame++ != 0xFF) || (*pFrame++ != 0xE0))
		{// APP0
			envir() << "WNCMJPEGVideoStreamSource::afterGettingFrame1: APP0\n";
			break;
		}
		
		u_int32_t segment_length = (pFrame[0] << 8) + pFrame[1];
		pFrame += segment_length;
		fQtableLength = 0;
		
		int j = fQtableLength;
		
		if ( (pFrame > pFrame_end) || (*pFrame++ != 0xFF) || (*pFrame++ != 0xDB)) 
		{ // DQT Y
			envir() << "WNCMJPEGVideoStreamSource::afterGettingFrame1: DQT Y\n";
			break;
		}
		
		segment_length = (pFrame[0] << 8) | pFrame[1]; //table length
		assert(segment_length == 67);
		
		u_int8_t element_precision = pFrame[2] >> 4;
		
		assert(element_precision == 0);

		if (0 == element_precision) 
		{
			fPrecision &= ~0x1;
			fQtableLength += 64;
		}
		else if (1 == element_precision) 
		{
			fPrecision |= 0x1;
			fQtableLength += 64*2;
		} 
		else
		{
			break;
		}
		
		for (int k = 3; j < fQtableLength; j++, k++)
		{
			fQuantizationTables[j] = pFrame[k];
		}

		pFrame += segment_length;

		if ((pFrame > pFrame_end) || (*pFrame++ != 0xFF) || (*pFrame++ != 0xDB))  
		{// DQT Cb/Cr
			break;
		}
		
		segment_length = (pFrame[0] << 8) | pFrame[1];
		assert(segment_length == 67);

		element_precision = pFrame[2] >> 4;
		assert(element_precision == 0);

		if (0 == element_precision) 
		{
			fPrecision &= ~0x2;
			fQtableLength += 64;
		}
		else if (1 == element_precision) 
		{
			fPrecision |= 0x2;
			fQtableLength += 64*2;
		} 
		else 
		{
			break;
		}
		
		for (int k = 3; j < fQtableLength; j++, k++) 
		{
			fQuantizationTables[j] = pFrame[k];
		}

		pFrame += segment_length;

		if ((pFrame > pFrame_end) || (*pFrame++ != 0xFF) || (*pFrame++ != 0xC0))  
		{// SOF0
			break;
		}
		
		segment_length = (pFrame[0] << 8) | pFrame[1];
		
		unsigned int i = 2;
		
		u_int8_t precision = pFrame[i++]; // 1 byte
		assert (precision == 8);
		fHeight = (pFrame[i++] << 5) | (pFrame[i++] >> 3);
		fWidth = (pFrame[i++] << 5) | (pFrame[i++] >> 3);
		
		u_int8_t component_num = pFrame[i++];
		assert (component_num == 3); //YUV

		u_int8_t component_id[3];
		u_int8_t sampling_factor[3];
		u_int8_t Qtable_num[3];
		
		for (int j = 0; j < component_num; j++)
		{
			component_id[j] = pFrame[i++];
			sampling_factor[j] = pFrame[i++];
			Qtable_num[j] = pFrame[i++];
		}
		
		if ((component_id[0] == 1 && sampling_factor[0] == 0x21 && Qtable_num[0] == 0) &&
			(component_id[1] == 2 && sampling_factor[1] == 0x11 && Qtable_num[1] == 1) &&
			(component_id[2] == 3 && sampling_factor[2] == 0x11 && Qtable_num[2] == 1)) 
		{
			fType = 0;	// YUV 4:2:2
		}
		else if ((component_id[0] == 1 && sampling_factor[0] == 0x22 && Qtable_num[0] == 0) &&
				 (component_id[1] == 2 && sampling_factor[1] == 0x11 && Qtable_num[1] == 1) &&
				 (component_id[2] == 3 && sampling_factor[2] == 0x11 && Qtable_num[2] == 1)) 
		{
			fType = 1;	// YUV 4:2:0
		}
		else
		{
			break;
		}
		
		assert(i == segment_length);
		pFrame += segment_length;

		for (int k = 0; k < 4; k++) 
		{
			if ((pFrame > pFrame_end) || (*pFrame++ != 0xFF) || (*pFrame++ != 0xC4)) 
			{// DHT Y-DC diff, Y-AC-Coef, Cb/Cr-DC diff, Cb/Cr-AC-Coef
				break;
			}
			
			segment_length = (pFrame[0]<<8) + pFrame[1];
			pFrame += segment_length;
		}
		
		if ((pFrame > pFrame_end) || (*pFrame++ != 0xFF) || (*pFrame++ != 0xDA)) 
		{
			break;
		}
		
		segment_length = (pFrame[0] << 8) + pFrame[1];
		pFrame += segment_length;
		fFrameSize = pFrame_end - pFrame;
		memmove(fTo, pFrame, fFrameSize);
	}while(0);

	fNumTruncatedBytes = numTruncatedBytes;
  	fPresentationTime = presentationTime;
  	fDurationInMicroseconds = durationInMicroseconds;

	afterGetting(this);
}

