/*
 * Copyright (C) 2005-2006 WIS Technologies International Ltd.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and the associated README documentation file (the
 * "Software"), to deal in the Software without restriction, including
 * without limitation the rights to use, copy, modify, merge, publish,
 * distribute, sublicense, and/or sell copies of the Software, and to
 * permit persons to whom the Software is furnished to do so.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 * OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
 * CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
 * TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
 * SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
// An application that streams audio/video
// using a built-in RTSP server.
// main program

#include "liveMedia.hh"
#include "BasicUsageEnvironment.hh"

#include "basetypes.h"
#include "Options.hh"
#include "UnicastStreaming.hh"
#include "WISInput.hh"
//#include "MulticastStreaming.hh"

portNumBits rtspServerPortNum = 554;

list_t stream_list;

size_t streams_meter(const void *el)
{
	return sizeof(struct stream_cfg_s);
}

int main(int argc, char** argv) 
{
	int verbosityLevel = 0;
	
  	// Begin by setting up our usage environment:
  	TaskScheduler *scheduler = BasicTaskScheduler::createNew();
	
  	UsageEnvironment *env = BasicUsageEnvironment::createNew(*scheduler);

	UserAuthenticationDatabase *authDB = NULL;
	UserAuthenticationDatabase* authDBForREGISTER = NULL;

	portNumBits tunnelOverHTTPPortNum = 0;

	char *username = NULL;
	char *password = NULL;
	char streamName[2 << 10];
	char proxiedStreamURL[2 << 10] = {0};
	char *url = NULL;
	char *proxyStreamURL = NULL;
	
  	// Create the RTSP server:
  	RTSPServer *rtspServer = NULL;
	
	WISInput *inputDevice = NULL;

	Boolean streamRTPOverTCP = True;
	
#ifdef ACCESS_CONTROL
	// To implement client access control to the RTSP server, do the following:
	authDB = new UserAuthenticationDatabase;
	authDB->addUserRecord("username1", "password1"); // replace these with real strings
	// Repeat the above with each <username>, <password> that you wish to allow
	// access to the server.
#endif

	do
	{		
		*env << "Initializing...\n";

		list_init(&stream_list);
		list_attributes_copy(&stream_list, streams_meter, 1);
		
		if (init_params(*env, argc, argv) < 0)
		{
			*env << "Initial parameter err!\n";
			break;
		}
				
    	rtspServer = RTSPServer::createNew(*env, rtspServerPortNum, authDB);
		//rtspServer = RTSPServerWithREGISTERProxying::createNew(*env, rtspServerPortNum, authDB, authDBForREGISTER, 65, streamRTPOverTCP, verbosityLevel);
		
    	if (rtspServer == NULL) 
		{
      		*env << "Failed to create RTSP server: " << env->getResultMsg() << "\n";
      		break;
    	}

		inputDevice = WISInput::createNew(*env);
		
	  	if (inputDevice == NULL) 
		{
	    	*env << "Failed to create WIS input device: " << env->getResultMsg() << "\n";
	    	break;
	  	}

		
		int num_of_uri = 0;
		int uri_no = 0;
		
		ServerMediaSession *sms = NULL;

		struct stream_cfg_s *stream = NULL;
	
		while (!list_empty(&stream_list))
		{
			*env << "list size: " << list_size(&stream_list) << "\n";
			
			stream = (struct stream_cfg_s *) list_fetch(&stream_list);
			
			{
				num_of_uri = stream->num_of_uri;

				for (uri_no = 0; uri_no < num_of_uri; uri_no++)
				{
					snprintf(streamName, sizeof(streamName), stream->uri[uri_no]);
					sms = ServerMediaSession::createNew(*env, streamName, NULL, streamDescription, streamingMode == STREAMING_MULTICAST_SSM);
				
					url = rtspServer->rtspURL(sms);
					*env << "Play this stream using the URL:\n\t" << url << "\n";
					delete[] url;
					
					setupUnicastStreaming(*inputDevice, sms, stream->stream_id, stream->video.format);
					setupUnicastStreaming(*inputDevice, sms, stream->stream_id, stream->audio.format);
				
					rtspServer->addServerMediaSession(sms);
				}
				
			#if 0	
				snprintf(proxiedStreamURL, sizeof(proxiedStreamURL), url);
				delete[] url;
				
				for (uri_no = 0; uri_no < stream->num_of_uri; uri_no++)
				{
					snprintf(streamName, sizeof(streamName), stream->uri[uri_no]);

					sms = ProxyServerMediaSession::createNew(*env, rtspServer, proxiedStreamURL, streamName, username, password, tunnelOverHTTPPortNum, verbosityLevel);
					
					proxyStreamURL = rtspServer->rtspURL(sms);
					*env << "proxying the stream \"" << proxiedStreamURL << "\"\n";
     				*env << "\tPlay this stream using the URL: " << proxyStreamURL << "\n";
     				delete[] proxyStreamURL;

					rtspServer->addServerMediaSession(sms);
			
				}
			#endif	
			}
		
		}
		
		setMediaRTPSinkBufferSize();
		
		*env << "...done initializing\n";
		// Also, attempt to create a HTTP server for RTSP-over-HTTP tunneling.
  		// Try first with the default HTTP port (80), and then with the alternative HTTP
  		// port numbers (8000 and 8080).

  		if (rtspServer->setUpTunnelingOverHTTP(80) || rtspServer->setUpTunnelingOverHTTP(8000) || rtspServer->setUpTunnelingOverHTTP(8080)) 
		{
    		*env << "\n(We use port " << rtspServer->httpServerPortNum() << " for optional RTSP-over-HTTP tunneling.)\n";
  		} 
		else 
		{
    		*env << "\n(RTSP-over-HTTP tunneling is not available.)\n";
  		}
		
  		// Begin the LIVE555 event loop:
  		env->taskScheduler().doEventLoop(); // does not return

  		// If "doEventLoop()" *did* return, we'd now do this to reclaim resources before exiting:
  		if (streamingMode != STREAMING_UNICAST && streamingMode != STREAMING_UNICAST_THROUGH_DARWIN) 
		{
    		//reclaimMulticastStreaming();
  		}
		
	}while (0);

  	Medium::close(rtspServer); // will also reclaim "sms" and its "ServerMediaSubsession"s
  	Medium::close(inputDevice);
	
    delete authDB;
  	delete[] streamDescription;
	
  	env->reclaim();
 	delete scheduler;

	list_destroy(&stream_list);
  	return 0; // only to prevent compiler warning
}
