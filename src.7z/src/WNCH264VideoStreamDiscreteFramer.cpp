#include "WNCH264VideoStreamDiscreteFramer.hh"

static int findNalu_amba (NALU * nalus, u_int32_t * count, u_int8_t *bitstream, u_int32_t streamSize)
{
	int index = -1;
	u_int8_t * bs = bitstream;
	u_int32_t head;
	u_int8_t nalu_type;

	u_int8_t *last_byte_bitstream = bitstream + streamSize - 1;

	while (bs <= last_byte_bitstream) {

		head = (bs[3] << 24) | (bs[2] << 16) | (bs[1] << 8) | bs[0];
	//	printf("head 0x%x: 0x%x, 0x%x, 0x%x, 0x%x\n", head, bs[0], bs[1], bs[2], bs[3]);

		if (head == 0x01000000) {	// little ending
			index++;
			// we find a nalu
			bs += 4;		// jump to nalu type
			nalu_type = 0x1F & bs[0];
			nalus[index].nalu_type = nalu_type;
			nalus[index].addr = bs;

			if (index  > 0) {	// Not the first NALU in this stream
				nalus[index -1].size = nalus[index].addr - nalus[index -1].addr - 4; // cut off 4 bytes of delimiter
			}
//			printf("	nalu type %d\n", nalus[index].nalu_type);

			if ((nalu_type == NALU_TYPE_NONIDR) ||
				(nalu_type == NALU_TYPE_IDR)) {
				// Calculate the size of the last NALU in this stream
				nalus[index].size =  last_byte_bitstream - bs + 1;
				break;
			}
		}
		else if (bs[3] != 0) {
			bs += 4;
		} else if (bs[2] != 0) {
			bs += 3;
		} else if (bs[1] != 0) {
			bs += 2;
		} else {
			bs += 1;
		}
	}

	*count = index + 1;
	if (*count == 0) {
		if (streamSize == 0) {
			printf("stream ended.\n");
		} else {
			printf("No nalu found in the bitstream!\n");
		}
		return -1;
	}
	return 0;
}


WNCH264VideoStreamDiscreteFramer*
WNCH264VideoStreamDiscreteFramer::createNew(UsageEnvironment& env, FramedSource* inputSource) {
  return new WNCH264VideoStreamDiscreteFramer(env, inputSource);
}

WNCH264VideoStreamDiscreteFramer
::WNCH264VideoStreamDiscreteFramer(UsageEnvironment& env, FramedSource* inputSource)
  : H264or5VideoStreamDiscreteFramer(264, env, inputSource), fNaluCurrIndex(0), fNaluCount(0){
}

WNCH264VideoStreamDiscreteFramer::~WNCH264VideoStreamDiscreteFramer() {
}

Boolean WNCH264VideoStreamDiscreteFramer::isH264VideoStreamFramer() const {
  return True;
}

void WNCH264VideoStreamDiscreteFramer::doGetNextFrame() {
  // Arrange to read data (which should be a complete H.264 or H.265 NAL unit)
  // from our data source, directly into the client's input buffer.
  // After reading this, we'll do some parsing on the frame.
	
  	if (fNaluCurrIndex >= fNaluCount)
  	{
    	fInputSource->getNextFrame(fBuffer, sizeof fBuffer,
                               	   afterGettingFrame, this,
                                   FramedSource::handleClosure, this);
  	}
	else
	{	
		afterGettingFrame1(fFrameSize, 0, fPresentationTime, fDurationInMicroseconds);
	}
}

void WNCH264VideoStreamDiscreteFramer
::afterGettingFrame(void* clientData, unsigned frameSize,
                    unsigned numTruncatedBytes,
                    struct timeval presentationTime,
                    unsigned durationInMicroseconds) {
  WNCH264VideoStreamDiscreteFramer* source = (WNCH264VideoStreamDiscreteFramer*)clientData;
  source->afterGettingFrame1(frameSize, numTruncatedBytes, presentationTime, durationInMicroseconds);
}

void WNCH264VideoStreamDiscreteFramer
::afterGettingFrame1(unsigned frameSize, unsigned numTruncatedBytes,
                     struct timeval presentationTime,
                     unsigned durationInMicroseconds) {
  // Get the "nal_unit_type", to see if this NAL unit is one that we want to save a copy of:
  	//envir() << "WNCH264VideoStreamDiscreteFramer::afterGettingFrame1(): fNaluCurrIndex = " << fNaluCurrIndex << " fNaluCount = " << fNaluCount << "\n";
  	u_int8_t nal_unit_type;

  	if (fNaluCurrIndex >= fNaluCount)
  	{	
		findNalu_amba(fNalus, &fNaluCount, fBuffer, frameSize);
		fNaluCurrIndex = 0;
  	}

	while (fNalus[fNaluCurrIndex].nalu_type == NALU_TYPE_SEI) 
	{
		fNaluCurrIndex++;
	}
			
	memcpy(fTo, fNalus[fNaluCurrIndex].addr, fNalus[fNaluCurrIndex].size);	
	
  	if (frameSize >= 1) 
	{
    	nal_unit_type = fTo[0]&0x1F;
  	}
	else 
	{
    	// This is too short to be a valid NAL unit, so just assume a bogus nal_unit_type
    	nal_unit_type = 0xFF;
  	}

  	// Begin by checking for a (likely) common error: NAL units that (erroneously) begin with a
  	// 0x00000001 or 0x000001 'start code'.  (Those start codes should only be in byte-stream data;
  	// *not* data that consists of discrete NAL units.)
  	// Once again, to be clear: The NAL units that you feed to a "WNCH264VideoStreamDiscreteFramer"
  	// MUST NOT include start codes.
  	if (fNalus[fNaluCurrIndex].size >= 4 && fTo[0] == 0 && fTo[1] == 0 && ((fTo[2] == 0 && fTo[3] == 1) || fTo[2] == 1)) 
	{
    	envir() << "WNCH264VideoStreamDiscreteFramer error: MPEG 'start code' seen in the input\n";
  	} 
	else if (isVPS(nal_unit_type)) 
	{ // Video parameter set (VPS)
    	saveCopyOfVPS(fTo, fNalus[fNaluCurrIndex].size);
  	}
	else if (isSPS(nal_unit_type)) 
	{ // Sequence parameter set (SPS)
    	saveCopyOfSPS(fTo, fNalus[fNaluCurrIndex].size);
  	}
	else if (isPPS(nal_unit_type))
	{ // Picture parameter set (PPS)
    	saveCopyOfPPS(fTo, fNalus[fNaluCurrIndex].size);
  	}

  	fPictureEndMarker = nalUnitEndsAccessUnit(nal_unit_type);

  	// Finally, complete delivery to the client:
  	fFrameSize = fNalus[fNaluCurrIndex].size;
  	fNumTruncatedBytes = numTruncatedBytes;
  	fPresentationTime = presentationTime;
  	fDurationInMicroseconds = durationInMicroseconds;
	fNaluCurrIndex++;
  	afterGetting(this);
	//envir() << "WNCH264VideoStreamDiscreteFramer::afterGettingFrame1\n";
}

Boolean WNCH264VideoStreamDiscreteFramer::nalUnitEndsAccessUnit(u_int8_t nal_unit_type) {
  // Check whether this NAL unit ends the current 'access unit' (basically, a video frame).
  //  Unfortunately, we can't do this reliably, because we don't yet know anything about the
  // *next* NAL unit that we'll see.  So, we guess this as best as we can, by assuming that
  // if this NAL unit is a VCL NAL unit, then it ends the current 'access unit'.
  //
  // This will be wrong if you are streaming multiple 'slices' per picture.  In that case,
  // you can define a subclass that reimplements this virtual function to do the right thing.

  return isVCL(nal_unit_type);
}

