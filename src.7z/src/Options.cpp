/*
 * Copyright (C) 2005-2006 WIS Technologies International Ltd.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and the associated README documentation file (the
 * "Software"), to deal in the Software without restriction, including
 * without limitation the rights to use, copy, modify, merge, publish,
 * distribute, sublicense, and/or sell copies of the Software, and to
 * permit persons to whom the Software is furnished to do so.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 * OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
 * CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
 * TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
 * SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
// Option variables, modifiable from the command line:
// Implementation

#include "Options.hh"
#include "TV.hh"
#include "Err.hh"
#include <GroupsockHelper.hh>
#include <getopt.h>

// Initialize option variables to default values:

enum numeric_short_options {
	OPTARGS_URI = 1000,
	OPTARGS_VIDEO_BITRATE,
	OPTARGS_VIDEO_RTP_PORT,
	OPTARGS_AUDIO_BITRATE,
	OPTARGS_AUDIO_RTP_PORT,
	OPTARGS_AUDIO_SAMPLE_RATE,
	OPTARGS_AUDIO_CHANNELS
};

//PackageFormat packageFormat = PFMT_SEPARATE_STREAMS;

UserAuthenticationDatabase* authDB = NULL;

const char *short_options = "p:S:v:a:D:u:";

const struct option long_options[] = {
	{"uri", 1, 0, OPTARGS_URI},
	{"v-br", 1, 0, OPTARGS_VIDEO_BITRATE},
	{"v-rtp-p", 1, 0, OPTARGS_VIDEO_RTP_PORT},
	{"a-br", 1, 0, OPTARGS_AUDIO_BITRATE},
	{"a-rtp-p", 1, 0, OPTARGS_AUDIO_RTP_PORT},
	{"a-spl-r", 1, 0, OPTARGS_AUDIO_SAMPLE_RATE},
	{"a-chs", 1, 0, OPTARGS_AUDIO_CHANNELS},
	{0, 0, 0, 0}
};

char* streamDescription = strDup("RTSP/RTP streams provided by WNC Crop.");
char* remoteDSSNameOrAddress = NULL;

unsigned videoBitrate = 5 << 20;
unsigned audioBitrate = (48 * 2 * 16) << 10;
unsigned audioSamplingFrequency = 48000;
unsigned audioNumChannels = 2;
unsigned audioOutputBitrate = 0; // default: we're not encoding to MPEG audio

StreamingMode streamingMode = STREAMING_UNICAST;
netAddressBits multicastAddress = 0;

int init_params(UsageEnvironment& env, int argc, char** argv) 
{
	int c;
	int option_index = 0;

	struct stream_cfg_s *stream = NULL;
	
	while((c = getopt_long(argc, argv, short_options, long_options, &option_index)) >= 0)
	{
		env << "c = " << c << "\n";

		if (!list_empty(&stream_list) && NULL == stream)
		{
			break;
		}
		
		switch (c)
		{
			case 'p': 
			{
				int rtspServerPortNumArg = atoi(optarg);
				
				if (rtspServerPortNumArg > 0 && rtspServerPortNumArg < 65536)
				{
					rtspServerPortNum = rtspServerPortNumArg;

					env << "RTSP port num: " << optarg << "\n";
				}
				else 
				{
					env << "Invalid RTSP port num argument: " << optarg << "\n";
				}
				
				break;
			}
			case 'S':
			{	
				if (NULL != stream)
				{
					list_append(&stream_list, (const void *) stream);
					free(stream);
				}

				stream = NULL;
				
				if (NULL == (stream = (struct stream_cfg_s *) calloc(1, sizeof(struct stream_cfg_s))))
				{
					env << "calloc() err!\n";
					break;
				}
				
				stream->stream_id = atoi(optarg);
				
				env << "New stream\n";
				break;
			}
			case OPTARGS_URI:
			{	
				stream->uri[stream->num_of_uri++] = optarg;
				env << "uri: " << optarg << "\n";
				env << "num_of_uri = " << stream->num_of_uri << "\n";
				break;
			}
			case 'v':
			{	
				snprintf(stream->video.format, sizeof(stream->video.format), optarg);
				env << "video-codec: " << optarg << "\n";
				break;
			}
			case OPTARGS_VIDEO_RTP_PORT:
			{
				int videoRTPPortNumArg = atoi(optarg);;
				
				if (videoRTPPortNumArg > 0 && videoRTPPortNumArg < 65536 && (videoRTPPortNumArg & 1) == 0)
				{
					stream->video.rtp_port = videoRTPPortNumArg;

					env << "video RTP port num: " << optarg << "\n";
				}
				else
				{
					env << "Invalid video RTP port num argument: " << optarg;
					
					if ((videoRTPPortNumArg & 1) != 0) 
					{
						env << " (must be even)";
					}
					
					env << "\n";
				}
				
				break;
			}
			case OPTARGS_VIDEO_BITRATE:
			{	
				stream->video.bitrate = atol(optarg);
				env << "video-bitrate: " << optarg << "\n";
				break;
			}
			case 'a': 
			{	
				snprintf(stream->audio.format, sizeof(stream->audio.format), optarg);
				break;
			}
			case OPTARGS_AUDIO_RTP_PORT:
			{
				int audioRTPPortNumArg = atoi(optarg);
				
				if (audioRTPPortNumArg > 0 && audioRTPPortNumArg < 65536 && (audioRTPPortNumArg & 1) == 0)
				{
					stream->audio.rtp_port = audioRTPPortNumArg;
				}
				else
				{
					env << "Invalid audio RTP port num argument: " << optarg;
					
					if ((audioRTPPortNumArg & 1) != 0)
						env << " (must be even)";
					env << "\n";
				}
				
				break;
			}
			case OPTARGS_AUDIO_BITRATE:
			{	
				stream->audio.bitrate = atol(optarg);
				break;
			}
			case OPTARGS_AUDIO_SAMPLE_RATE:
			{	
				stream->audio.sample_rate = atoi(optarg);
				break;
			}
			case OPTARGS_AUDIO_CHANNELS:
			{	
				stream->audio.channels = atoi(optarg);
				break;
			}
			// streamDescription:
			case 'D': 
			{
				streamDescription = strDup(optarg);
				break;
			}
			
			// authDB:
			case 'u': 
			{
			  	// Parse "optarg" for a colon, indicating username:password 
			  	char* username = optarg;
			  	char* password;
			  
			  	for (password = optarg; *password != '\0'; ++password)
			  	{
				  	if (*password == ':')
				  	{
					  	*password++ = '\0';
					 	break;
				  	}
			  	}
			  
			  	if (authDB == NULL) 
			  	{
				  	authDB = new UserAuthenticationDatabase(streamDescription);
			  	}
			  
			  	authDB->addUserRecord(username, password);
			  
			  	break;
			}
			
			// streamingMode:
			case 'm': 
			{
				  streamingMode = STREAMING_MULTICAST_SSM;
				  break;
			}
			default:
				return -1;
		}
	}
	
	if (optind < argc) 
  	{
    	env << "Ignoring non-option command-line arguments: ";
	
    	while (optind < argc) 
    	{
			env << argv[optind++] << " ";
    	}
	
    	env << "\n";
  	}

	if (list_empty(&stream_list))
	{
		env << "no stream\n";
		return -1;
	}
	
	return 0;
	
#if 0
 	// Determine whether we're streaming multicast, and if so, what flavor:
  	if (streamingMode == STREAMING_MULTICAST_SSM) 
  	{
   		if (multicastAddress == 0) 
    	{
			multicastAddress = chooseRandomIPv4SSMAddress(env);
    	}
  	} 
  	else if (multicastAddress != 0) 
  	{
    	streamingMode = STREAMING_MULTICAST_ASM;
  	}
#endif
}

void reclaimArgs() 
{
  	delete authDB;
  	delete[] streamDescription;
}
