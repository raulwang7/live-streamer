/*
 * Copyright (C) 2005-2006 WIS Technologies International Ltd.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and the associated README documentation file (the
 * "Software"), to deal in the Software without restriction, including
 * without limitation the rights to use, copy, modify, merge, publish,
 * distribute, sublicense, and/or sell copies of the Software, and to
 * permit persons to whom the Software is furnished to do so.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 * OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
 * CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
 * TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
 * SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
// An interface to the WNC capture raw data.
// Implementation
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/shm.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <linux/netlink.h>
#include <malloc.h>

#include "WISInput.hh"
#include "Err.hh"
#include <fcntl.h>
#include <dirent.h>
#include <sys/stat.h>
#include <sys/ioctl.h>
#include <sys/mman.h>
#include <sys/poll.h>

#include "basetypes.h"
#include "video_info.h"
#include "wnc_notify_params.h"
#include "audio_info.h"

////////// WISOpenFileSource definition //////////

// A common "FramedSource" subclass, used for reading from an open file:

class WISOpenFileSource: public FramedSource 
{
	protected:
  		WISOpenFileSource(UsageEnvironment& env, WISInput& input, int fileNo, unsigned streamId);
  		virtual ~WISOpenFileSource();
  		virtual void readFromFile() = 0;

	private: // redefined virtual functions:
  		virtual void doGetNextFrame();
  		static void incomingDataHandler(void* arg, int mask);
  		void incomingDataHandler1();

	protected:
  		WISInput& fInput;
  		int fFileNo;
  		unsigned fStreamId;
		Boolean fDoneFlag;
};


////////// WISVideoOpenFileSource definition //////////

class WISVideoOpenFileSource: public WISOpenFileSource 
{
	public:
  		static WISVideoOpenFileSource * createNew(UsageEnvironment& env, WISInput& input, unsigned streamId);
  		virtual ~WISVideoOpenFileSource();
		
	private:
  		WISVideoOpenFileSource(UsageEnvironment& env, WISInput& input, int fileNo, unsigned streamId);
		
		// redefined virtual functions:
  		virtual void readFromFile();
		
	private:
  		unsigned fFrameNum;
		u_int8_t fQuality;
};


////////// WISAudioOpenFileSource definition //////////

class WISAudioOpenFileSource: public WISOpenFileSource 
{
	public:
  		static WISAudioOpenFileSource * createNew(UsageEnvironment& env, WISInput& input, unsigned streamId);
  		virtual ~WISAudioOpenFileSource();
/*
		unsigned getNumChannels();
		unsigned getSamplingFrequency();
		unsigned getBitsPerSample();
*/

	private:
		 WISAudioOpenFileSource(UsageEnvironment& env, WISInput& input, int fileNo, unsigned streamId);
		 
		// redefined virtual functions:
  		virtual void readFromFile();

	private:
		unsigned char* fAudioBitsStream;
		
/*		
	private:
		unsigned fNumChannels;
		unsigned fSamplingFrequency;
		unsigned fBitsPerSample;
*/
};

////////// WISInput implementation //////////
Boolean WISInput::fHaveInitialized = False;
unsigned char* WISInput::fVideoBitsStream = NULL;

WISInput* WISInput::createNew(UsageEnvironment& env) 
{
  	if (!fHaveInitialized) 
	{
    	if (!initialize(env)) 
			return NULL;
		
    	fHaveInitialized = True;
  	}

  	return new WISInput(env);
}

FramedSource* WISInput::videoSource(unsigned streamId) {
  return WISVideoOpenFileSource::createNew(envir(), *this, streamId);
}

FramedSource* WISInput::audioSource(unsigned streamId) {
  return WISAudioOpenFileSource::createNew(envir(), *this, streamId);
}

WISInput::WISInput(UsageEnvironment& env)
  : Medium(env) {
}

WISInput::~WISInput() 
{
	if (fVideoBitsStream)
	{
		shmdt(fVideoBitsStream);
		fVideoBitsStream = NULL;
	}
}

Boolean WISInput::initialize(UsageEnvironment& env) {
  do 
  {
    if (!attachVideoMemory(env)) 
		break;

    return True;
  } while (0);

  // An error occurred
  return False;
}

Boolean WISInput::attachVideoMemory(UsageEnvironment& env) 
{
	char debugStr[512] = {0};
	
	int ipcs_id = -1;
	
	unsigned mem_size = 0;

	key_t mem_key;

	do
	{
		mem_size = VIDEO_STREAM_SIZE;
		mem_key = VIDEO_STREAM_KEY;

		if ((ipcs_id = shmget(mem_key, mem_size, 0600)) < 0)
		{
			snprintf(debugStr, sizeof(debugStr), "[%s:%d]\t%s\tshmget() err!\n", __FILE__, __LINE__, __func__);
			env << *debugStr;
			break;
		}

		if (fVideoBitsStream == NULL)
		{
			if ((fVideoBitsStream = (unsigned char *) shmat(ipcs_id, NULL, 0)) < 0)
			{
				snprintf(debugStr, sizeof(debugStr), "[%s:%d]\t%s\tshmat() err!\n", __FILE__, __LINE__, __func__);
				env << *debugStr;
				break;
			}
		}
		
		return True;
	} while (0);

	return False;
}

////////// WISOpenFileSource implementation //////////

WISOpenFileSource
::WISOpenFileSource(UsageEnvironment& env, WISInput& input, int fileNo, unsigned streamId)
  : FramedSource(env),
    fInput(input), fFileNo(fileNo), fStreamId(streamId), fDoneFlag(False) {
}

WISOpenFileSource::~WISOpenFileSource() {
  envir().taskScheduler().turnOffBackgroundReadHandling(fFileNo);
  ::close(fFileNo);
}

void WISOpenFileSource::doGetNextFrame() {
  //envir() << "WISOpenFileSource::doGetNextFrame()\n";
  // Await the next incoming data on our FID:
  	envir().taskScheduler().turnOnBackgroundReadHandling(fFileNo, (TaskScheduler::BackgroundHandlerProc*)&incomingDataHandler, this);
}

void WISOpenFileSource
::incomingDataHandler(void* arg, int /*mask*/) {
  WISOpenFileSource* source = (WISOpenFileSource*) arg;	
  source->incomingDataHandler1();
}

void WISOpenFileSource::incomingDataHandler1() {
  	// Read the data from our file into the client's buffer:
  	//envir() << "WISOpenFileSource::incomingDataHandler1()\n";
  	readFromFile();

	if (fDoneFlag)
	{
  		// Stop handling any more input, until we're ready again:
  		envir().taskScheduler().turnOffBackgroundReadHandling(fFileNo);

  		// Tell our client that we have new data:
  		afterGetting(this);
	}
}


////////// WISVideoOpenFileSource implementation //////////
WISVideoOpenFileSource * WISVideoOpenFileSource
::createNew(UsageEnvironment& env, WISInput& input, unsigned streamId) 
{
	int nl_fd = -1;
	
    struct sockaddr_nl nl_addr;

	do
	{
	    if ((nl_fd = socket(AF_NETLINK, SOCK_RAW, NETLINK_WNC_VIDEO_SYNC)) < 0)
	    {
			env << "socket() err!\n";
			break;
		}
		
		memset(&nl_addr, 0, sizeof(nl_addr));
		nl_addr.nl_family = AF_NETLINK;
		//addr.nl_pid = getpid(); /* self pid */ 
		nl_addr.nl_groups = 1; /* mcast groups */ 
		
		if (bind(nl_fd, (struct sockaddr *) &nl_addr, sizeof(nl_addr)) < 0)
		{
			env << "bind() err!\n";
			break;
		}

		return new WISVideoOpenFileSource(env, input, nl_fd, streamId);
		
	} while(0);

	return NULL;
}

WISVideoOpenFileSource
::WISVideoOpenFileSource(UsageEnvironment& env, WISInput& input, int fileNo,unsigned streamId)
  : WISOpenFileSource(env, input, fileNo, streamId) {
}

WISVideoOpenFileSource::~WISVideoOpenFileSource() {
}

void WISVideoOpenFileSource::readFromFile() 
{	
	int l = -1;
	
	struct sockaddr_nl dest_addr;
	struct msghdr msg;
	struct nlmsghdr * nlh = NULL;
	struct iovec iov;
	
	char *bitsStream_start = NULL;
	
	frame_info_t *sync_info = NULL;

	do
	{
		fDoneFlag = False;
		
		memset(&dest_addr, 0, sizeof(struct sockaddr_nl));
		dest_addr.nl_family = AF_NETLINK;
		dest_addr.nl_pid = 0;
		dest_addr.nl_groups = 1;

		if ((nlh = (struct nlmsghdr*) calloc(1, NLMSG_SPACE(MAX_PAYLOAD))) == NULL)
		{
			break;
		}
		
		nlh->nlmsg_pid = getpid();
		iov.iov_base = (void *) nlh;
		iov.iov_len = NLMSG_SPACE(MAX_PAYLOAD);
		memset(&msg, 0, sizeof(msg));
		msg.msg_name = (void *)&dest_addr;
		msg.msg_namelen = sizeof(dest_addr);
		msg.msg_iov = &iov;
		msg.msg_iovlen = 1;

		l = recvmsg(fFileNo, &msg, 0);

		if (l > 0)
		{	
			sync_info = (frame_info_t*) NLMSG_DATA(msg.msg_iov->iov_base);
			
			if (sync_info->stream_id == fStreamId)
			{
				if (!sync_info->stream_end)
				{
					//gettimeofday(&fPresentationTime, NULL);
					
					fPresentationTime.tv_sec = sync_info->sys_pts / 1000;
					fPresentationTime.tv_usec = (sync_info->sys_pts % 1000) * 1000;
					
				/*
					gettimeofday(&fPresentationTime, NULL);
			
					if ((sync_info->frame_num - fFrameNum) > 1)
					{
						envir() << "frame loss\n";
					}
				*/
					//envir() << "frame num = " << sync_info->frame_num << "\n";
					fQuality = sync_info->jpeg_quality;
					fFrameNum = sync_info->frame_num;
					fFrameSize = sync_info->size;
					fNumTruncatedBytes = 0;

					if (fFrameSize > fMaxSize)
					{
						envir() << "WISVideoOpenFileSource::readFromFile():fFrameSize = " << fFrameSize << "; fMaxSize = " << fMaxSize << "\n";
						fNumTruncatedBytes = fFrameSize - fMaxSize;
						fFrameSize = fMaxSize;
					}
			
					bitsStream_start = (char *) fInput.fVideoBitsStream + sync_info->data_addr_offset;
					memcpy(fTo, bitsStream_start, fFrameSize);
				
					fDoneFlag = True;
				}
			}
		}
		
		delete nlh;
		
	}while(0);
}


////////// WISAudioOpenFileSource implementation //////////
WISAudioOpenFileSource * WISAudioOpenFileSource
::createNew(UsageEnvironment& env, WISInput& input, unsigned streamId)
{
	int nl_fd = -1;

	struct sockaddr_nl nl_addr;
	
	do
	{
	    if ((nl_fd = socket(AF_NETLINK, SOCK_RAW, NETLINK_WNC_AUDIO_SYNC)) < 0)
	    {
			env << "socket() err!\n";
			break;
		}
		
		memset(&nl_addr, 0, sizeof(nl_addr));
		nl_addr.nl_family = AF_NETLINK;
		//addr.nl_pid = getpid(); /* self pid */ 
		nl_addr.nl_groups = 1; /* mcast groups */ 
		
		if (bind(nl_fd, (struct sockaddr *) &nl_addr, sizeof(nl_addr)) < 0)
		{
			env << "bind() err!\n";
			break;
		}

		return new WISAudioOpenFileSource(env, input, nl_fd, streamId);
		
	} while(0);

	return NULL;
}

WISAudioOpenFileSource
::WISAudioOpenFileSource(UsageEnvironment& env, WISInput& input, int fileNo, unsigned streamId)
  : WISOpenFileSource(env, input, fileNo, streamId), fAudioBitsStream(NULL) {
}

WISAudioOpenFileSource::~WISAudioOpenFileSource() 
{
  	if (fAudioBitsStream)
  	{
  		shmdt(fAudioBitsStream);
  	}
}

void WISAudioOpenFileSource::readFromFile() 
{
	int nr = -1;
	static int chunk_num = 0;
	
	struct sockaddr_nl dest_addr;
	struct msghdr msg;
	struct nlmsghdr *nlh = NULL;
	struct iovec iov;
	
	char *bitsStream_start = NULL;
	
	audio_info_t *audio_info = NULL;

	do
	{
		fDoneFlag = False;
		
		memset(&dest_addr, 0, sizeof(struct sockaddr_nl));
		dest_addr.nl_family = AF_NETLINK;
		dest_addr.nl_pid = 0;
		dest_addr.nl_groups = 1;
		
		if ((nlh = (struct nlmsghdr *) calloc(1, NLMSG_SPACE(MAX_PAYLOAD))) == NULL)
		{
			break;
		}
		
		nlh->nlmsg_pid = getpid();
		iov.iov_base = (void *) nlh;
		iov.iov_len = NLMSG_SPACE(MAX_PAYLOAD);
		memset(&msg, 0, sizeof(msg));
		msg.msg_name = (void *)&dest_addr;
		msg.msg_namelen = sizeof(dest_addr);
		msg.msg_iov = &iov;
		msg.msg_iovlen = 1;

		nr = recvmsg(fFileNo, &msg, 0);
		
		if (nr > 0)
		{
			audio_info = (audio_info_t *) NLMSG_DATA(msg.msg_iov->iov_base);
			
			if (audio_info->stream_id == fStreamId)
			{
				if (fAudioBitsStream == NULL)
				{
					int ipcs_id = -1;

					unsigned mem_size = audio_info->audio_ipcs_size;
					ipcs_id = shmget(audio_info->audio_ipcs_key, mem_size, 0600);
					fAudioBitsStream = (unsigned char *) shmat(ipcs_id, NULL, 0);
				}

				/*
				if ((audio_info->chunk_num - chunk_num) > 1)
				{
					envir() << "chunk_num = " << chunk_num << "\n";
				}
				
				chunk_num = audio_info->chunk_num;
				*/
				
				//gettimeofday(&fPresentationTime, NULL);
				
				fPresentationTime.tv_sec = audio_info->sys_pts / 1000;
				fPresentationTime.tv_usec = (audio_info->sys_pts % 1000) * 1000;
					
				fFrameSize = audio_info->size;
				//envir() << "audio FrameSize = " << fFrameSize << "\n";
				fNumTruncatedBytes = 0;

				if (fFrameSize > fMaxSize)
				{
					envir() << "WISAudioOpenFileSource::readFromFile():fFrameSize = " << fFrameSize << "; fMaxSize = " << fMaxSize << "\n";
					fNumTruncatedBytes = fFrameSize - fMaxSize;
					fFrameSize = fMaxSize;
				}
				
				bitsStream_start = (char *) fAudioBitsStream + audio_info->offset;
				memcpy(fTo, bitsStream_start, fFrameSize);

				fDoneFlag = True;
			}
		}
		
		delete nlh;
	} while (0);
}

/*
unsigned WISAudioOpenFileSource::getNumChannels() {
	
}

unsigned WISAudioOpenFileSource::getSamplingFrequency() {
	
}

unsigned WISAudioOpenFileSource::getBitsPerSample() {
	
}
*/
